# rastersysteme

**Swiss 60-column grid slide generator.** Takes Markdown, outputs PPTX on a Müller-Brockmann / Gerstner-inspired modular grid with Musica Viva layout arrangements.

## Quick Start

```bash
npm install pptxgenjs
node raster.js slides.md
```

Output: `slides.pptx`

## Usage

```bash
node raster.js <input.md> [output.pptx] [--theme light|dark|red|blue] [--ratio 16:9|4:3]
```

## Markdown Format

Slides are separated by `---`. Standard markdown elements map to slide content:

```markdown
# Title Slide

Subtitle text here

- bullet one
- bullet two
- bullet three

---

## Second Slide

### SECTION LABEL

- Point A
- Point B

> This is a callout blockquote

```notes
Speaker notes go here — rendered in PPTX notes pane, not on slide.
```​

---

<!-- layout: stagger -->

## Forced Layout

- These items
- Will appear
- As cascading
- Colour bars

---

<!-- layout: section -->
<!-- bg: 0F2A4A -->

Custom background section slide
```

## Elements

| Markdown | Slide Element |
|----------|--------------|
| `# Heading` | Title text |
| `## Heading` | Subtitle |
| `### Heading` | Small-caps section label |
| `- item` | Bullet point |
| `> quote` | Callout / blockquote |
| `[text](url)` | Clickable link |
| `` ```notes ``` `` | Speaker notes (hidden) |
| `<!-- layout: name -->` | Force layout |
| `<!-- bg: HEX -->` | Override background |

## Layouts

Auto-detected based on content, or forced with `<!-- layout: name -->`:

| Layout | When Used | Style |
|--------|-----------|-------|
| `title` | First slide | Red accent block + topic pills |
| `section` | Title-only or forced | Dark bg, large centred text |
| `bullets` | 1–3 bullets | Numbered list with accent dots |
| `stagger` | 4+ bullets | Musica Viva cascading bars |
| `split` | Title + body text | Left title zone, right content |
| `rotated` | Has blockquote | Vertical rotated title bar |
| `fragment` | Links / many items | Fragmented colour grid |
| `overlap` | Forced | Two overlapping colour fields |
| `arc` | Forced | Concentric circles + text |
| `blank` | Forced | Empty slide |

## Themes

Four built-in themes:

- **light** — warm white background, dark text (default)
- **dark** — near-black background, light text
- **red** — light bg with red accent emphasis
- **blue** — cool blue-grey palette

## Grid System

- **60 columns × 40 rows** on a 10" × 5.625" (16:9) canvas
- **0.5" margins** on all sides
- **0.02" micro-gutters** between cells
- Column width: ~0.130"
- Row height: ~0.096"

60 is divisible by 2, 3, 4, 5, 6, 10, 12, 15, 20, and 30 — one grid for any subdivision.

Guides are hierarchical:
- **÷12** (every 12th col) — strong divisions (5 zones)
- **÷5** (every 5th col) — medium divisions
- **÷1** (every col) — fine adjustments

## Programmatic Use

```javascript
const { generate, parseMarkdown, createGrid, THEMES, LAYOUTS } = require("./raster.js");

// Generate a deck
await generate("slides.md", "output.pptx", { theme: "dark", ratio: "16:9" });

// Parse markdown only
const slides = parseMarkdown(fs.readFileSync("slides.md", "utf-8"));

// Access the grid
const g = createGrid(10, 5.625);
console.log(g.cx(30)); // x position of column 30
console.log(g.cw(12)); // width spanning 12 columns
```

## Google Slides Workflow

1. Generate `.pptx` with this tool
2. Upload to Google Drive
3. Open with Google Slides (imports cleanly)
4. Enable View → Snap to → Guides for smart snapping
5. Existing shapes act as snap targets for new elements

## PowerPoint Workflow

1. Open the generated `.pptx`
2. View → Show group → dialog launcher → Grid and Guides
3. Set spacing to **1/16"** for fine snapping
4. Check **Snap objects to grid**
5. Keep **Smart guides** enabled — they snap to template shape edges

Hold **Alt** while dragging to temporarily bypass all snapping.

## Credits

Grid system principles after Josef Müller-Brockmann (*Grid Systems in Graphic Design*), Karl Gerstner (*Designing Programmes*), and Wolfgang Weingart.
