#!/usr/bin/env node
/**
 * rastersysteme — Swiss 60-column grid slide generator
 * 
 * Usage:
 *   node raster.js input.md [output.pptx] [--theme dark|light|red|blue] [--ratio 16:9|4:3]
 * 
 * Markdown format:
 *   Slides separated by ---
 *   # Heading 1 → title text
 *   ## Heading 2 → subtitle
 *   ### Heading 3 → section label
 *   - Bullet items
 *   > Blockquote → callout
 *   ```notes → speaker notes (not rendered)
 *   <!-- layout: name --> → force a layout
 *   <!-- bg: color --> → background override
 *   [text](url) → links preserved as text
 * 
 * Available layouts (auto-detected or forced):
 *   title, section, bullets, stagger, overlap, fragment, rotated, arc, split, blank
 */

const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

// ═══════════════════════════════════════════════════════
// GRID SYSTEM
// ═══════════════════════════════════════════════════════

function createGrid(slideWidth, slideHeight, cols = 60, rows = 40, margin = 0.5, gutter = 0.02) {
  const iw = slideWidth - margin * 2;
  const ih = slideHeight - margin * 2;
  const cw = (iw - (cols - 1) * gutter) / cols;
  const rh = (ih - (rows - 1) * gutter) / rows;

  return {
    SW: slideWidth, SH: slideHeight,
    M: margin, G: gutter,
    COLS: cols, ROWS: rows,
    IW: iw, IH: ih, CW: cw, RH: rh,
    cx: (col) => margin + col * (cw + gutter),
    cy: (row) => margin + row * (rh + gutter),
    cw: (span) => span * cw + (span - 1) * gutter,
    ch: (span) => span * rh + (span - 1) * gutter,
  };
}

// ═══════════════════════════════════════════════════════
// THEMES
// ═══════════════════════════════════════════════════════

const THEMES = {
  light: {
    bg: "F8F5F0", bgAlt: "FFFFFF", bgDark: "1A1A1A",
    text: "1A1A1A", textMid: "5C5549", textLight: "8C8478",
    accent: "E63222", accent2: "1B4FA0", accent3: "2A7A4B", accent4: "F2C12E",
    white: "FFFFFF", black: "1A1A1A", grey: "D4CEC4",
  },
  dark: {
    bg: "1A1A1A", bgAlt: "2A2A2A", bgDark: "111111",
    text: "F0EBE3", textMid: "B8B0A2", textLight: "8C8478",
    accent: "E63222", accent2: "4A90D9", accent3: "5CB87A", accent4: "F2C12E",
    white: "FFFFFF", black: "1A1A1A", grey: "444444",
  },
  red: {
    bg: "F8F5F0", bgAlt: "FFFFFF", bgDark: "8B1A10",
    text: "1A1A1A", textMid: "5C5549", textLight: "8C8478",
    accent: "E63222", accent2: "1B4FA0", accent3: "2A7A4B", accent4: "F2C12E",
    white: "FFFFFF", black: "1A1A1A", grey: "D4CEC4",
  },
  blue: {
    bg: "F0F4F8", bgAlt: "FFFFFF", bgDark: "0F2A4A",
    text: "1A1A1A", textMid: "4A5568", textLight: "8C9AAF",
    accent: "1B4FA0", accent2: "E63222", accent3: "2A7A4B", accent4: "F2C12E",
    white: "FFFFFF", black: "1A1A1A", grey: "CBD5E0",
  },
};

// ═══════════════════════════════════════════════════════
// MARKDOWN PARSER
// ═══════════════════════════════════════════════════════

function parseMarkdown(md) {
  const raw = md.split(/\n---\n/);
  return raw.map((slideText, idx) => {
    const slide = {
      index: idx,
      title: null,
      subtitle: null,
      sectionLabel: null,
      bullets: [],
      body: [],
      blockquote: null,
      notes: null,
      layout: null,
      bgOverride: null,
      links: [],
      raw: slideText.trim(),
    };

    // Extract directives
    const layoutMatch = slideText.match(/<!--\s*layout:\s*(\w+)\s*-->/);
    if (layoutMatch) slide.layout = layoutMatch[1];

    const bgMatch = slideText.match(/<!--\s*bg:\s*([#\w]+)\s*-->/);
    if (bgMatch) slide.bgOverride = bgMatch[1].replace("#", "");

    // Extract notes
    const notesMatch = slideText.match(/```notes\n([\s\S]*?)```/);
    if (notesMatch) slide.notes = notesMatch[1].trim();

    // Clean text (remove directives, notes, bg image refs)
    let clean = slideText
      .replace(/<!--[\s\S]*?-->/g, "")
      .replace(/```notes\n[\s\S]*?```/g, "")
      .trim();

    // Parse lines
    const lines = clean.split("\n");
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      if (trimmed.startsWith("# ") && !trimmed.startsWith("## ")) {
        slide.title = trimmed.replace(/^#\s+/, "");
      } else if (trimmed.startsWith("## ")) {
        slide.subtitle = trimmed.replace(/^##\s+/, "");
      } else if (trimmed.startsWith("### ")) {
        slide.sectionLabel = trimmed.replace(/^###\s+/, "");
      } else if (trimmed.match(/^\s*[-*]\s+/)) {
        slide.bullets.push(trimmed.replace(/^\s*[-*]\s+/, ""));
      } else if (trimmed.startsWith("> ")) {
        slide.blockquote = (slide.blockquote || "") + trimmed.replace(/^>\s*/, "") + "\n";
      } else if (trimmed.match(/^\[.*\]\(.*\)$/)) {
        const m = trimmed.match(/\[([^\]]*)\]\(([^)]*)\)/);
        if (m) slide.links.push({ text: m[1], url: m[2] });
      } else if (!trimmed.startsWith("```")) {
        slide.body.push(trimmed);
      }
    }

    if (slide.blockquote) slide.blockquote = slide.blockquote.trim();

    return slide;
  }).filter(s => s.raw.length > 0);
}

// ═══════════════════════════════════════════════════════
// LAYOUT DETECTION
// ═══════════════════════════════════════════════════════

function detectLayout(slide, index, total) {
  if (slide.layout) return slide.layout;

  // First slide → title
  if (index === 0) return "title";

  // Last slide with minimal content → blank or section
  if (index === total - 1 && !slide.title && slide.body.length <= 1) return "section";

  // Has title + subtitle but little else → section
  if (slide.title && slide.subtitle && slide.bullets.length === 0 && slide.body.length <= 1) return "section";

  // Many bullets (4+) → stagger
  if (slide.bullets.length >= 4) return "stagger";

  // Has bullets → bullets
  if (slide.bullets.length > 0) return "bullets";

  // Has blockquote → rotated (use the quote as feature text)
  if (slide.blockquote) return "rotated";

  // Has title + body text → split
  if (slide.title && slide.body.length > 0) return "split";

  // Title only → section
  if (slide.title) return "section";

  // Links list → fragment
  if (slide.links.length > 0) return "fragment";

  return "split";
}

// ═══════════════════════════════════════════════════════
// LAYOUT RENDERERS
// ═══════════════════════════════════════════════════════

function addSlideNumber(s, g, num, theme, dark = false) {
  s.addText(String(num).padStart(2, "0"), {
    x: g.cx(55), y: g.SH - 0.32, w: g.cw(5), h: 0.2,
    fontSize: 8, fontFace: "Helvetica Neue",
    color: dark ? theme.textMid : theme.textLight,
    align: "right", margin: 0,
  });
}

const LAYOUTS = {

  // ─── TITLE ───
  title(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgDark };

    // Accent block
    s.addShape(pres.shapes.RECTANGLE, {
      x: g.cx(0), y: g.cy(0), w: g.cw(24), h: g.ch(22),
      fill: { color: theme.accent },
    });

    const titleText = slide.title || slide.body[0] || "Untitled";
    const titleSize = titleText.length > 40 ? 26 : titleText.length > 25 ? 30 : 34;
    s.addText(titleText, {
      x: g.cx(1), y: g.cy(1), w: g.cw(22), h: g.ch(20),
      fontSize: titleSize, fontFace: "Helvetica Neue",
      color: theme.white, bold: true, lineSpacingMultiple: 0.95,
      valign: "top", margin: 0,
    });

    if (slide.subtitle) {
      s.addText(slide.subtitle, {
        x: g.cx(28), y: g.cy(4), w: g.cw(30), h: g.ch(6),
        fontSize: 24, fontFace: "Helvetica Neue",
        color: theme.white, bold: true, margin: 0,
      });
    }

    // Bullets as topic pills
    const colors = [theme.accent2, theme.accent3, theme.accent4];
    slide.bullets.forEach((b, i) => {
      const row = 16 + i * 5;
      if (row > 35) return;
      s.addShape(pres.shapes.RECTANGLE, {
        x: g.cx(28), y: g.cy(row), w: g.cw(22), h: g.ch(4),
        fill: { color: colors[i % 3], transparency: i === 2 ? 35 : 20 },
      });
      s.addText(b, {
        x: g.cx(29), y: g.cy(row), w: g.cw(20), h: g.ch(4),
        fontSize: 11, fontFace: "Helvetica Neue",
        color: theme.white, bold: true, margin: 0, valign: "middle",
      });
    });

    // Body lines as subtitle
    if (!slide.subtitle && slide.body.length > 0) {
      const bodyText = slide.body.filter(b => b !== titleText).join("\n");
      if (bodyText) {
        s.addText(bodyText, {
          x: g.cx(28), y: g.cy(6), w: g.cw(30), h: g.ch(10),
          fontSize: 14, fontFace: "Helvetica Neue",
          color: theme.textMid, margin: 0, lineSpacingMultiple: 1.3,
        });
      }
    }

    s.addShape(pres.shapes.OVAL, {
      x: g.cx(25), y: g.cy(22), w: 0.22, h: 0.22,
      fill: { color: theme.accent4 },
    });

    addSlideNumber(s, g, num, theme, true);
  },

  // ─── SECTION ───
  section(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgDark };

    const title = slide.title || slide.subtitle || slide.body[0] || "";
    s.addText(title, {
      x: g.cx(4), y: g.cy(10), w: g.cw(52), h: g.ch(12),
      fontSize: 40, fontFace: "Helvetica Neue",
      color: theme.white, bold: true, margin: 0, valign: "middle",
    });

    if (slide.subtitle && slide.title) {
      s.addText(slide.subtitle, {
        x: g.cx(4), y: g.cy(22), w: g.cw(40), h: g.ch(5),
        fontSize: 18, fontFace: "Helvetica Neue",
        color: theme.textMid, margin: 0,
      });
    }

    if (slide.sectionLabel) {
      s.addText(slide.sectionLabel.toUpperCase(), {
        x: g.cx(4), y: g.cy(5), w: g.cw(30), h: g.ch(3),
        fontSize: 8, fontFace: "Helvetica Neue",
        color: theme.accent, bold: true, margin: 0, charSpacing: 3,
      });
    }

    // Accent bar
    s.addShape(pres.shapes.RECTANGLE, {
      x: g.cx(4), y: g.cy(28), w: g.cw(8), h: g.ch(0.5),
      fill: { color: theme.accent },
    });

    // Links
    slide.links.forEach((l, i) => {
      s.addText(`${l.text} →`, {
        x: g.cx(4), y: g.cy(30 + i * 3), w: g.cw(40), h: g.ch(3),
        fontSize: 10, fontFace: "Helvetica Neue",
        color: theme.accent2, margin: 0,
        hyperlink: { url: l.url },
      });
    });

    addSlideNumber(s, g, num, theme, true);
  },

  // ─── BULLETS ───
  bullets(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    if (slide.sectionLabel) {
      s.addText(slide.sectionLabel.toUpperCase(), {
        x: g.cx(0), y: g.cy(0), w: g.cw(25), h: g.ch(3),
        fontSize: 8, fontFace: "Helvetica Neue",
        color: theme.accent, bold: true, margin: 0, charSpacing: 3,
      });
    }

    if (slide.title) {
      s.addText(slide.title, {
        x: g.cx(0), y: g.cy(slide.sectionLabel ? 3 : 0),
        w: g.cw(35), h: g.ch(7),
        fontSize: 30, fontFace: "Helvetica Neue",
        color: theme.text, bold: true, margin: 0,
      });
    }

    const startRow = (slide.title ? 11 : 4);
    const colors = [theme.accent, theme.accent2, theme.accent3, theme.accent4];

    slide.bullets.forEach((b, i) => {
      const row = startRow + i * Math.min(6, Math.floor(28 / slide.bullets.length));
      if (row > 36) return;
      const rh = Math.min(5, Math.floor(26 / slide.bullets.length));

      // Number circle
      s.addShape(pres.shapes.OVAL, {
        x: g.cx(0), y: g.cy(row), w: 0.24, h: 0.24,
        fill: { color: colors[i % 4] },
      });
      s.addText(String(i + 1), {
        x: g.cx(0), y: g.cy(row), w: 0.24, h: 0.24,
        fontSize: 9, fontFace: "Helvetica Neue",
        color: theme.white, bold: true, align: "center", valign: "middle", margin: 0,
      });

      s.addText(b, {
        x: g.cx(3), y: g.cy(row) - 0.02, w: g.cw(55), h: g.ch(rh),
        fontSize: 14, fontFace: "Helvetica Neue",
        color: theme.text, margin: 0, valign: "top",
      });
    });

    if (slide.blockquote) {
      s.addShape(pres.shapes.RECTANGLE, {
        x: g.cx(0), y: g.cy(34), w: g.cw(58), h: g.ch(5),
        fill: { color: theme.accent, transparency: 92 },
      });
      s.addText(slide.blockquote, {
        x: g.cx(1), y: g.cy(34), w: g.cw(56), h: g.ch(5),
        fontSize: 11, fontFace: "Helvetica Neue",
        color: theme.textMid, italic: true, margin: 0, valign: "middle",
      });
    }

    addSlideNumber(s, g, num, theme);
  },

  // ─── STAGGER (Musica Viva vertical cascade) ───
  stagger(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    if (slide.title) {
      s.addText(slide.title, {
        x: g.cx(0), y: g.cy(0), w: g.cw(40), h: g.ch(8),
        fontSize: 28, fontFace: "Helvetica Neue",
        color: theme.text, bold: true, margin: 0,
      });
    }

    const colors = [theme.accent, theme.accent2, theme.accent3, theme.accent4];
    const startRow = slide.title ? 10 : 2;
    const step = Math.min(7, Math.floor(30 / slide.bullets.length));
    const colStep = Math.min(8, Math.floor(30 / slide.bullets.length));

    slide.bullets.forEach((b, i) => {
      const col = i * colStep;
      const row = startRow + i * step;
      if (row > 36) return;
      const c = colors[i % 4];
      const textOnDark = c === theme.accent4 ? theme.black : theme.white;

      s.addShape(pres.shapes.RECTANGLE, {
        x: g.cx(col), y: g.cy(row), w: g.cw(Math.min(42, 60 - col)), h: g.ch(Math.max(4, step - 1)),
        fill: { color: c, transparency: c === theme.accent4 ? 25 : 15 },
      });
      s.addText(b, {
        x: g.cx(col) + 0.12, y: g.cy(row), w: g.cw(Math.min(40, 58 - col)), h: g.ch(Math.max(4, step - 1)),
        fontSize: 15, fontFace: "Helvetica Neue",
        color: textOnDark, bold: true, margin: 0, valign: "middle",
      });
    });

    addSlideNumber(s, g, num, theme);
  },

  // ─── SPLIT (left title, right content) ───
  split(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    // Left zone
    s.addShape(pres.shapes.RECTANGLE, {
      x: g.cx(0), y: g.cy(0), w: g.cw(22), h: g.ch(40),
      fill: { color: theme.accent, transparency: 90 },
    });

    if (slide.sectionLabel) {
      s.addText(slide.sectionLabel.toUpperCase(), {
        x: g.cx(1), y: g.cy(1), w: g.cw(20), h: g.ch(3),
        fontSize: 8, fontFace: "Helvetica Neue",
        color: theme.accent, bold: true, margin: 0, charSpacing: 3,
      });
    }

    if (slide.title) {
      s.addText(slide.title, {
        x: g.cx(1), y: g.cy(slide.sectionLabel ? 5 : 2),
        w: g.cw(20), h: g.ch(14),
        fontSize: 28, fontFace: "Helvetica Neue",
        color: theme.text, bold: true, margin: 0,
      });
    }

    if (slide.subtitle) {
      s.addText(slide.subtitle, {
        x: g.cx(1), y: g.cy(18), w: g.cw(20), h: g.ch(6),
        fontSize: 14, fontFace: "Helvetica Neue",
        color: theme.textMid, margin: 0,
      });
    }

    // Right zone — body text + bullets
    const rightCol = 25;
    let row = 2;

    slide.body.forEach(line => {
      if (row > 35) return;
      s.addText(line, {
        x: g.cx(rightCol), y: g.cy(row), w: g.cw(33), h: g.ch(4),
        fontSize: 13, fontFace: "Helvetica Neue",
        color: theme.text, margin: 0,
      });
      row += 4;
    });

    slide.bullets.forEach((b, i) => {
      if (row > 35) return;
      s.addText(`${i + 1}.  ${b}`, {
        x: g.cx(rightCol), y: g.cy(row), w: g.cw(33), h: g.ch(4),
        fontSize: 12, fontFace: "Helvetica Neue",
        color: theme.textMid, margin: 0,
      });
      row += 4;
    });

    if (slide.blockquote) {
      s.addShape(pres.shapes.RECTANGLE, {
        x: g.cx(rightCol), y: g.cy(row), w: g.cw(33), h: g.ch(6),
        fill: { color: theme.accent, transparency: 92 },
      });
      s.addText(slide.blockquote, {
        x: g.cx(rightCol + 1), y: g.cy(row), w: g.cw(31), h: g.ch(6),
        fontSize: 11, fontFace: "Helvetica Neue",
        color: theme.textMid, italic: true, margin: 0, valign: "middle",
      });
    }

    // Links
    slide.links.forEach((l, i) => {
      if (row > 36) return;
      s.addText(`${l.text} →`, {
        x: g.cx(rightCol), y: g.cy(row + i * 3), w: g.cw(33), h: g.ch(3),
        fontSize: 10, fontFace: "Helvetica Neue",
        color: theme.accent2, margin: 0,
        hyperlink: { url: l.url },
      });
    });

    addSlideNumber(s, g, num, theme);
  },

  // ─── ROTATED (Musica Viva rotated type) ───
  rotated(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    // Red vertical bar — 13 cols
    s.addShape(pres.shapes.RECTANGLE, {
      x: g.cx(0), y: g.cy(0), w: g.cw(13), h: g.ch(40),
      fill: { color: theme.accent, transparency: 15 },
    });

    // Rotated title
    const rotTitle = slide.title || "—";
    const textW = Math.min(4.2, rotTitle.length * 0.3);
    const textH = 0.6;
    const centerX = g.cx(6.5);
    const centerY = g.cy(0) + g.ch(40) / 2;
    s.addText(rotTitle.toUpperCase(), {
      x: centerX - textW / 2, y: centerY - textH / 2,
      w: textW, h: textH,
      fontSize: 38, fontFace: "Helvetica Neue",
      color: theme.white, bold: true, margin: 0,
      rotate: 270, valign: "middle", align: "center",
    });

    // Divider
    s.addShape(pres.shapes.LINE, {
      x: g.cx(15), y: g.cy(3), w: 0, h: g.ch(34),
      line: { color: theme.text, width: 0.15, transparency: 85 },
    });

    // Body / blockquote
    const mainText = slide.blockquote || slide.body.join("\n") || "";
    if (mainText) {
      s.addText(mainText, {
        x: g.cx(17), y: g.cy(6), w: g.cw(40), h: g.ch(22),
        fontSize: 17, fontFace: "Helvetica Neue",
        color: theme.text, margin: 0, lineSpacingMultiple: 1.4,
      });
    }

    slide.bullets.forEach((b, i) => {
      s.addText(`— ${b}`, {
        x: g.cx(17), y: g.cy(28 + i * 3), w: g.cw(40), h: g.ch(3),
        fontSize: 12, fontFace: "Helvetica Neue",
        color: theme.textMid, margin: 0,
      });
    });

    addSlideNumber(s, g, num, theme);
  },

  // ─── FRAGMENT (Musica Viva fragmented grid) ───
  fragment(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    const items = [...slide.bullets, ...slide.links.map(l => l.text)];
    const colors = [theme.accent, theme.accent2, theme.accent3, theme.accent4, theme.black];

    // Auto-generate fragment positions
    const positions = [
      [0, 0, 18, 8], [20, 0, 18, 8], [40, 0, 18, 8],
      [0, 9, 18, 8], [20, 9, 18, 8], [40, 9, 18, 8],
      [0, 18, 18, 8], [20, 18, 18, 8], [40, 18, 28, 8],
    ];

    items.forEach((item, i) => {
      if (i >= positions.length) return;
      const [c, r, cs, rs] = positions[i];
      s.addShape(pres.shapes.RECTANGLE, {
        x: g.cx(c), y: g.cy(r + 10), w: g.cw(cs), h: g.ch(rs),
        fill: { color: colors[i % 5], transparency: i % 5 === 4 ? 10 : 40 },
      });
      const textColor = (colors[i % 5] === theme.accent4) ? theme.black : theme.white;
      s.addText(item, {
        x: g.cx(c) + 0.08, y: g.cy(r + 10) + 0.04,
        w: g.cw(cs - 1), h: g.ch(rs - 1),
        fontSize: 11, fontFace: "Helvetica Neue",
        color: textColor, bold: true, margin: 0, valign: "middle",
      });
    });

    if (slide.title) {
      s.addText(slide.title, {
        x: g.cx(0), y: g.cy(1), w: g.cw(40), h: g.ch(8),
        fontSize: 26, fontFace: "Helvetica Neue",
        color: theme.text, bold: true, margin: 0,
      });
    }

    addSlideNumber(s, g, num, theme);
  },

  // ─── OVERLAP (Musica Viva overlapping fields) ───
  overlap(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    // Two overlapping fields
    s.addShape(pres.shapes.RECTANGLE, {
      x: g.cx(0), y: g.cy(10), w: g.cw(32), h: g.ch(26),
      fill: { color: theme.accent, transparency: 35 },
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: g.cx(26), y: g.cy(10), w: g.cw(32), h: g.ch(26),
      fill: { color: theme.accent2, transparency: 40 },
    });

    if (slide.title) {
      s.addText(slide.title, {
        x: g.cx(0), y: g.cy(1), w: g.cw(40), h: g.ch(8),
        fontSize: 30, fontFace: "Helvetica Neue",
        color: theme.text, bold: true, margin: 0,
      });
    }

    // Split bullets across two fields
    const half = Math.ceil(slide.bullets.length / 2);
    slide.bullets.slice(0, half).forEach((b, i) => {
      s.addText(b, {
        x: g.cx(2), y: g.cy(14 + i * 5), w: g.cw(24), h: g.ch(4),
        fontSize: 13, fontFace: "Helvetica Neue",
        color: theme.white, margin: 0, valign: "middle",
      });
    });
    slide.bullets.slice(half).forEach((b, i) => {
      s.addText(b, {
        x: g.cx(28), y: g.cy(14 + i * 5), w: g.cw(28), h: g.ch(4),
        fontSize: 13, fontFace: "Helvetica Neue",
        color: theme.white, margin: 0, valign: "middle",
      });
    });

    // Body in overlap zone
    if (slide.body.length > 0) {
      s.addText(slide.body.join("\n"), {
        x: g.cx(2), y: g.cy(12), w: g.cw(28), h: g.ch(20),
        fontSize: 13, fontFace: "Helvetica Neue",
        color: theme.white, margin: 0, lineSpacingMultiple: 1.4,
      });
    }

    addSlideNumber(s, g, num, theme);
  },

  // ─── ARC ───
  arc(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };

    const acx = g.cx(35);
    const acy = g.cy(20);

    s.addShape(pres.shapes.OVAL, {
      x: acx - 2.2, y: acy - 2.2, w: 4.4, h: 4.4,
      fill: { color: theme.accent, transparency: 93 },
      line: { color: theme.accent, width: 3 },
    });
    s.addShape(pres.shapes.OVAL, {
      x: acx - 1.3, y: acy - 1.3, w: 2.6, h: 2.6,
      fill: { color: theme.accent2, transparency: 94 },
      line: { color: theme.accent2, width: 2 },
    });
    s.addShape(pres.shapes.OVAL, {
      x: acx - 0.12, y: acy - 0.12, w: 0.24, h: 0.24,
      fill: { color: theme.accent },
    });

    if (slide.title) {
      s.addText(slide.title, {
        x: g.cx(0), y: g.cy(2), w: g.cw(25), h: g.ch(10),
        fontSize: 40, fontFace: "Helvetica Neue",
        color: theme.text, bold: true, margin: 0,
      });
    }

    slide.body.forEach((line, i) => {
      s.addText(line, {
        x: g.cx(0), y: g.cy(14 + i * 4), w: g.cw(25), h: g.ch(4),
        fontSize: 13, fontFace: "Helvetica Neue",
        color: theme.textMid, margin: 0,
      });
    });

    addSlideNumber(s, g, num, theme);
  },

  // ─── BLANK ───
  blank(s, slide, g, theme, pres, num) {
    s.background = { color: theme.bgAlt };
    addSlideNumber(s, g, num, theme);
  },
};

// ═══════════════════════════════════════════════════════
// MAIN GENERATOR
// ═══════════════════════════════════════════════════════

async function generate(inputPath, outputPath, options = {}) {
  const themeName = options.theme || "light";
  const theme = THEMES[themeName] || THEMES.light;
  const ratio = options.ratio || "16:9";

  const pres = new pptxgen();

  let sw, sh;
  if (ratio === "4:3") {
    pres.layout = "LAYOUT_4x3";
    sw = 10; sh = 7.5;
  } else {
    pres.layout = "LAYOUT_16x9";
    sw = 10; sh = 5.625;
  }

  pres.author = "rastersysteme";
  pres.title = path.basename(inputPath, ".md");

  const g = createGrid(sw, sh);
  const md = fs.readFileSync(inputPath, "utf-8");
  const slides = parseMarkdown(md);

  slides.forEach((slide, idx) => {
    const layout = detectLayout(slide, idx, slides.length);
    const s = pres.addSlide();

    // Background override
    if (slide.bgOverride) {
      s.background = { color: slide.bgOverride };
    }

    // Speaker notes
    if (slide.notes) {
      s.addNotes(slide.notes);
    }

    const renderer = LAYOUTS[layout] || LAYOUTS.split;
    renderer(s, slide, g, theme, pres, idx + 1);
  });

  await pres.writeFile({ fileName: outputPath });
  return { slides: slides.length, output: outputPath, theme: themeName };
}

// ═══════════════════════════════════════════════════════
// CLI
// ═══════════════════════════════════════════════════════

if (require.main === module) {
  const args = process.argv.slice(2);

  if (args.length === 0 || args.includes("--help")) {
    console.log(`
  rastersysteme — Swiss 60-column grid slide generator

  Usage:
    node raster.js <input.md> [output.pptx] [options]

  Options:
    --theme <name>   Theme: light (default), dark, red, blue
    --ratio <r>      Aspect ratio: 16:9 (default), 4:3
    --help           Show this help

  Markdown format:
    Slides separated by ---
    # Title → slide title
    ## Subtitle
    ### Section Label → small caps label
    - Bullet points
    > Blockquote → callout text
    \`\`\`notes ... \`\`\` → speaker notes
    <!-- layout: name --> → force layout
    <!-- bg: HEXCOLOR --> → background override

  Layouts (auto-detected or forced):
    title     First slide, accent block + pills
    section   Dark background, large centred text
    bullets   Numbered bullets with accent dots
    stagger   Musica Viva cascading colour bars
    split     Left title zone, right content
    rotated   Vertical rotated title bar
    fragment  Fragmented colour grid of items
    overlap   Two overlapping colour fields
    arc       Concentric circles + left text
    blank     Empty slide
    `);
    process.exit(0);
  }

  const input = args[0];
  let output = args[1] && !args[1].startsWith("--") ? args[1] : input.replace(/\.md$/, ".pptx");

  const themeIdx = args.indexOf("--theme");
  const theme = themeIdx >= 0 ? args[themeIdx + 1] : "light";

  const ratioIdx = args.indexOf("--ratio");
  const ratio = ratioIdx >= 0 ? args[ratioIdx + 1] : "16:9";

  if (!fs.existsSync(input)) {
    console.error(`Error: File not found: ${input}`);
    process.exit(1);
  }

  generate(input, output, { theme, ratio })
    .then(result => {
      console.log(`✓ Generated ${result.slides} slides → ${result.output}`);
      console.log(`  Theme: ${result.theme} | Grid: 60×40 | Ratio: ${ratio}`);
    })
    .catch(err => {
      console.error("Error:", err.message);
      process.exit(1);
    });
}

module.exports = { generate, parseMarkdown, createGrid, THEMES, LAYOUTS };
