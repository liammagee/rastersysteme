# Introduction to Generative AI for Education

Workshop 1: Pedagogical Lens (I)

 - overview
 - assessments
 - what do we know about AI? how is it impacting eduction?

---

## Generative AI for Education: Overview

   - Welcome!

   - Theory - 1 hour
   - Breakout rooms / Group Discussion / Readings - 1 hour
   - Practice - 1 hour

```notes
Welcome! What's this course about? In 2026, in some sense, we no longer need a course introducing us to Generative AI - for education or for anything else.
```

---

## Structure

Built around 6 weekly themes

 - Week 1: Overview
 - Week 2: Historical Lens
 - Week 3: Technological Lens
 - Week 4: Practioners Lens
 - Week 5: Critical Lens
 - Week 6: Pedagogical  Lens
 - Week 7: Futurological Lens

---

## Assessment

- Formative: six responses to each week's questions (6 x 5% = 30%)
- Summative - an intervention: 70%
- What kind of intervention? Any of the following:
- Presentation (15-20 slides)
- A0 Conference Poster
- Research Paper
- School Curriculum
- Policy Document
- Comic strip
- Movie
- Mock product pitch / ad campaign for a new AI service

---

## Assessment Criteria

 - Weekly responses: Critical engagement with the material
 - Final Assessment: Responsiveness of intervention to challenges of AI
 - Critical response to course concepts and materials

---

<!-- layout: section -->

Workshop 1: Historical Lens

[Gen AI - Week 1](https://docs.google.com/presentation/d/1Ef2cOYSKH5goLC6U6ikBKZf7aBwqZtn2ifGeihnn-l4/edit)

---

<!-- layout: section -->

Workshop 2: Technological Lens

[Gen AI - Week 2](https://docs.google.com/presentation/d/1Hlvpcow63mGnqoDLvaCIOBu_I5LKFBc5qT2TkSdzDXo/edit)

---

<!-- layout: section -->

Workshop 3: Practitioner Lens

[Gen AI - Week 3](https://docs.google.com/presentation/d/1tm5q1JTfKU-YSJIKuFny1D2aU8-jMtwVxfRyBx9yGc4/edit)

---

<!-- layout: section -->

Workshop 4: Critical Lens

[Gen AI - Week 4](https://docs.google.com/presentation/d/1Sil2dxk73gQZInd99n3f2PvqsZkLzFqLCDxUTxHqNCk/edit)

[Gen AI - Week 5](https://docs.google.com/presentation/d/1Jfm7tsq58fX0kEOUcNGvuSKeoXW0flGFPUwpMWu5pmA/edit)

---

<!-- layout: section -->

Workshop 5: Pedagogical Lens (II)

[Gen AI - Week 6](https://docs.google.com/presentation/d/1-6sre1_FQSRBWxg03xjLYbp77iSljhDitDGbEhHzFhY/edit)

---

<!-- layout: section -->

Workshop 6: Showcase
